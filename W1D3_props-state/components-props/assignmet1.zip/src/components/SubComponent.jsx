const SubComponent = () => {
    return (
        <div>SubComponent</div>
    );
};

export default SubComponent;